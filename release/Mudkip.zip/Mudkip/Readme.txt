Mudkip Adventures

A game made in 72 hours.


Created by Raphael <raphael@fx-world.org>
Game engine by tri - Tomaz, Raphael, InsertWittyName



1. So, I herd u liek Mudkip?!

This game is made around the Pokemon character Mudkip, a water-type Pokemon.
You play Mudkip and your aim is to keep other wild Pokemon away from their
target (which oddly enough is your food you collected).
You can use your attacks and also to some degree block the enemies way to
keep them away from your precious berries.
At the start you will only have a tackle attack type, which allows you to deal
some damage and at the same time move back the enemies (and maybe even in chain).
As you earn experience, you will learn other attacks that are more powerful but
also might just work well in combination with tackle (for example, the bubble
attack).
If one of the wild Pokemon catched one of your berries, you are still able
to get it back, if you either hurt the enemy with tackle or watergun, or if
you knocked out the enemy completely before it can escape.



2. Status

Lv      - The level you are at. Possible range 1 - 99. For every level you gain more
          strength, healt points and aqua points and regenerate aqua points faster.
HP      - Health points. How many damage you can take (has no relevance in this game ;P)
AP      - Aqua points. How many water you have available to use for water-type attacks.
Berries - How many berries you still have. Game is over if you have no berries and
          all Pokemon carrying one have escaped.



3. Attacks

X:   Bubble - Deal little damage. 33% chance to 'freeze' the enemy for some time. Uses few aqua points.

Yep - only one made it into the compo release, because a 'last-minute' bug kept me busy for the last 5 hours
where I was starting to add the other attacks that were planned. I at least hoped I'd get the tackle
still done, but it wasn't possible because the game constantly hung up at the start so I couldn't try
out anything.
Later versions of the game will contain other attacks though and should make it more fun to play.



4. Known Bugs

- Sometimes the Pokemon just disappear when they catched a berry
- Sometimes the Pokemon get stuck at places



5. Contact

All comments, cheers, flames and bugreports plz go to raphael@fx-world.org

